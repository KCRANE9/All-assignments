#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  3 22:32:38 2017

@author: kathy.crane
"""

import numpy as np
z = np.random.normal(size=100)

S = 41.0
K = 40.0
r = 0.08
v = 0.30
T = 1.0
q = 0.0

M = 1000000
spot_t = np.empty((M,))
nudt = (r - q - 0.5 * v * v) * T
sigdt = v * np.sqrt(T)
z = np.random.normal(size=(M,))

for i in range(M):
    spot_t[i] = S * np.exp(nudt + sigdt * z[i]) 
    spot_t = S * np.exp(nudt + sigdt * z)
    
def CallPayoff(spot, strike):
    return np.maximum(spot - strike, 0.0)

def PutPayoff(spot, strike):
    return np.maximum(strike - spot, 0.0)

call_t = CallPayoff(spot_t, K)
billybobsthorntonsfirstcousintwiceremovedexwife = call_t.mean()

callPrc = np.exp(-r * T) * billybobsthorntonsfirstcousintwiceremovedexwife
callPrc

put_t = PutPayoff(spot_t, K)

putPrc = np.exp(-r * T) * put_t.mean()
putPrc

theCall = VanillaCallOption(X,T)
callPrice = EuropeanBinomialPricer(theCall, S, rate, volatility, dividend, steps)
print("The Two Period European Binomial Price is = {0:.4f}".format(callPrice))

thePut = VanillaPutOption(X,T)
putPrice = EuropeanBinomialPricer(thePut, S, rate, volatility, dividend, steps)
print("The European Binomial Put Price is = {0:.4f}".format(putPrice))