#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 13:56:29 2017

@author: kathy.crane
"""

import datetime

def fractionalAct(lastCoupon,nextCoupon,settleDate):
    remainingDays=(nextCoupon-settleDate)
    totalDays=(nextCoupon-lastCoupon)
    fractionalPeriod=(remainingDays/totalDays)
    return fractionalPeriod

def remaining(nextCoupon, settleDate):
    remainingDays=(nextCoupon-settleDate)
    return remainingDays

def total(nextCoupon, lastCoupon):
    totalDays=(nextCoupon-lastCoupon)
    return totalDays

lastCoupon=datetime.date(2017,5,15)
nextCoupon=datetime.date(2017,11,15)
settleDate=datetime.date(2017,7,21)


fractionalAct=fractionalAct(lastCoupon,nextCoupon,settleDate)
print("The fractional period is:",(fractionalAct))

remaining=remaining(nextCoupon,settleDate)
print("The remaining days is:", (remaining))

totalDays=total(nextCoupon,lastCoupon)
print("The total days is:", (totalDays))


def pv(fractionalAct, periods, ytm, frequency, faceValue, couponpmt):
    pv=[]
    payment = (faceValue*couponpmt)/frequency
    
    for i in range(periods*frequency):
        pvCoupons = payment/((1 + (ytm/frequency))**(fractionalAct + i))
        pv.append(pvCoupons)
        
    pvCoupons = sum(pv)
    
    pvFace = faceValue/((1+ytm/frequency)**(fractionalAct+(periods*frequency-1)))
    
    pv = pvCoupons + pvFace
    
    return pv

    
periods = 10
ytm = 0.024
frequency = 2
faceValue = 100
couponpmt = 0.02375

presentValue=pv(fractionalAct, periods, ytm, frequency, faceValue, couponpmt)
print("The full price of the bond is:", (presentValue))


def aI(fractionalAct,couponpmt,frequency,faceValue):
    aI = ((1-fractionalAct)*(couponpmt/frequency)*faceValue)
    return aI

currentaI=aI(fractionalAct,couponpmt,frequency,faceValue)
print("The accrued interest of the bond is:", (currentaI))

def flat(presentValue, currentaI):
    flat = (presentValue - currentaI)
    return flat

flattotal = flat(presentValue, currentaI)
print("The flat price of the bond is:", (flattotal))

    
#Fractional Periods.  Write a python program that takes as inputs:
#last coupon date, next coupon date, settlement date
#and prints the remaining days, total days, and fractional remaining period.  Assume US Treasury daycount.

#Present Value Loop.  Write a python program that takes as inputs:  
#fractional remaining period, total whole periods, yield to maturity, frequency, face value, and coupon payment
#and prints the full price of the bond.

#Component C.   Remaining 6 points.  Due 11/02/17.   Completed bond pricer 
#incorporating Components A and B and including accrued interest and flat price 
#matching the Bloomberg calculation for any US Treasury bond.



