#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 10 15:13:54 2017

@author: kathy.crane
"""
def print_header():
    print("Welcome to 'Computer Guess My Number'!")
    print("I'm thinking of a number between 1 and 100.")
    print("If the number is lower or higher please respond accordingly.")
    print("GOOD LUCK.")
    
def print_footer(number, tries):
    print("The computer guessed it! The number was", guess,)
    print("And it only took the computer", tries, "tries!")
    
def main():
    #print the greeting banner
    print_header()
    print("I'm going to guess your number between 1 and 100, if my guess is correct, type 'Correct'")
    print("if my guess is higher than your number type 'High'")
    print("If it's lower than your number, press 'Low'")
    lower_bound = 0
    upper_bound = 100
    guess = int((upper_bound + lower_bound)/2)
    done = False
    tries = 0
    response = input(guess)
    while done != True:
        if response == "High":
                upper_bound = guess
                guess = int((upper_bound + lower_bound)/2)
                response = input(guess)
        elif response == "Low":
                lower_bound = guess
                guess = int((upper_bound + lower_bound)/2)
                response = input(guess)
        elif response == "Correct":
                print("Nailed it! I got it in only", tries, "tries")
                done = True
        tries += 1
        
    print_footer(guess, tries)
    print("The computer's guess of", guess,"is correct!")  
  

if __name__ == '__main__':
    main()