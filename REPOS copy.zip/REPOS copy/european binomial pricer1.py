_# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
from scipy.stats import binom

class VanillaOption(object):
        def __init__(self, strike, expiry):
            self.strike = strike
            self.expiry = expiry
        def value(self,spot):
            pass
        
class VanillaCallOption(VanillaOption):
        def value(self, spot):
            max = np.maximum(spot - self.strike, 0.0)
            return max
class VanillaPutOption(VanillaOption):
    def value(self, spot):
        max = np.maximum(self.strike - spot, 0.0)
        return max
    
    
def EuropeanBinomialPricer(option, S, rate, volatility, dividend, steps):
     #expiry = option.expiry
     nodes = steps + 1
     spotT = 0.0
     callT = 0.0
     dt = T/steps
     u = np.exp(((rate - dividend)*dt) + volatility*np.sqrt(dt))
     d = np.exp(((rate - dividend)*dt) - volatility*np.sqrt(dt))
     pu = (np.exp((rate - dividend)*dt)-d)/(u-d)
     pd=1-pu
     
     for i in range(nodes):
         spotT = S*(u**(steps-i))*(d**(i))
         callT+= option.value(spotT)*binom.pmf(steps - i, steps, pu)
     price = callT*np.exp(-rate*T)
     return price
 
    
     
    #thePut = VanilllaPutPayoff(K,T)
    #putPrice = EuropeanBinomialPricer(thePut, S, r, v, div, N)

S = 41
X = 40
rate = 0.08
T = 1.0
volatility = 0.30
#?u = 1.2
dividend = 0.0
steps = 3
    
theCall = VanillaCallOption(X,T)
callPrice = EuropeanBinomialPricer(theCall, S, rate, volatility, dividend, steps)
print("The Two Period European Binomial Price is = {0:.4f}".format(callPrice))

thePut = VanillaPutOption(X,T)
putPrice = EuropeanBinomialPricer(thePut, S, rate, volatility, dividend, steps)
print("The European Binomial Put Price is = {0:.4f}".format(putPrice))

#S, X, r, u, d, T
    #for i in range(nodes)