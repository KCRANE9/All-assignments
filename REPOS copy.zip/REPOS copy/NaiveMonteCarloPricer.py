#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 15 14:44:03 2017

@author: kathy.crane
"""
import numpy as np
from scipy.stats import binom
import abc
from numpy import maximum 

class Payoff(object, metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def expiry(self):
        """Get the expiry date."""
        pass

    @expiry.setter
    @abc.abstractmethod
    def expiry(self, newExpiry):
        """Set the expiry date."""
        pass
    
    @abc.abstractmethod
    def payoff(self):
        pass


class VanillaPayoff(Payoff):
    def __init__(self, expiry, strike, payoff):
        self.__expiry = expiry
        self.__strike = strike
        self.__payoff = payoff
        
    @property
    def expiry(self):
        return self.__expiry

    @expiry.setter
    def expiry(self, new_expiry):
        self.__expiry = new_expiry
    
    @property 
    def strike(self):
        return self.__strike
    
    @strike.setter
    def strike(self, new_strike):
        self.__strike = new_strike

    def payoff(self, spot):
        return self.__payoff(self, spot)

    
def call_payoff(option, spot):
    return maximum(spot - option.strike, 0.0)

def put_payoff(option, spot):
    return maximum(option.strike - spot, 0.0)
'''
class VanillaOption(object):
        def __init__(self, strike, expiry):
            self.strike = strike
            self.expiry = expiry
        def value(self,spot):
            pass
        
class VanillaCallOption(VanillaOption):
        def value(self, spot):
            max = np.maximum(spot - self.strike, 0.0)
            return max
class VanillaPutOption(VanillaOption):
    def value(self, spot):
        max = np.maximum(self.strike - spot, 0.0)
        return max
    '''
def NaiveMonteCarloPricer(option, spot, rate, vol, div, M):
   # expiry = option.expiry
    #strike = option.strike
    #(spot, rate, vol, div) = data.get_data()
    #replications = engine.replications
    spot_t = np.empty((M,))
    nudt = (r - q - 0.5 * v * v) * T
    sigdt = v * np.sqrt(T)
    z = np.random.normal(size=(M,))

#for i in range(M):
#    spot_t[i] = S * np.exp(nudt + sigdt * z[i])
    spot_t = S * np.exp(nudt + sigdt * z)
    
    
    
    dt = T/ M
    disc = np.exp(-rate * dt)
    
    z = np.random.normal(size = M)
    spotT = spot * np.exp((rate - div - 0.5 * vol * vol) * dt + vol * np.sqrt(dt) * z)
    payoffT = option.payoff(spotT)

    prc = payoffT.mean() * disc

    return prc
'''
class BlackScholesPricingEngine(PricingEngine):
    def __init__(self, payoff_type, pricer):
        self.__payoff_type = payoff_type
        self.__pricer = pricer

    @property
    def payoff_type(self):
        return self.__payoff_type

    def calculate(self, option, data):
        return self.__pricer(self, option, data)
     '''
    #thePut = VanilllaPutPayoff(K,T)
    #putPrice = EuropeanBinomialPricer(thePut, S, r, v, div, N)
def main():
    spot = 41.0
    K = 40.0
    rate = 0.08
    vol = 0.30
    T = 1.0
    div = 0.0
    M = 1000000
    theCall = VanillaPayoff(Payoff)
    callPrice = NaiveMonteCarloPricer(call_payoff, spot, rate, volatility, div, M)
    print("The American Binomial Call Price is = {0:.4f}".format(callPrice))
    thePut = VanillaPayoff(Payoff)
    putPrice = NaiveMonteCarloPricer(put_payoff, spot, rate, volatility, div, M)
    print("The American Binomial Put Price is = {0:.4f}".format(putPrice))
main()

