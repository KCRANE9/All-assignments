#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  1 15:08:30 2017


@author: kathy.crane
"""

import random

def print_header():
    print("Welcome to 'Guess My Number'!")
    print("I'm thinking of a number between 1 and 100.")
    print("Try to guess it in as few attempts as possible./n")
    
def print_footer(the_number, tries):
    print("You guessed it! The number was", the_number)
    print("And it only took you", tries, "tries!")
    print("/n/nPress the enter key to exit.")
    
def main():
    #print the greeting banner
    print_header()
    
    # set the initial values
    the_number  =  random.randint(1, 100)
    guess = int(input(the_number))
    tries = 1
    
    # the game loop
    while guess != the_number:
        if guess > the_number:
            print("Lower ...")
        else:
            print("Higher...")
            
        guess = int(input("Take a guess: "))
        tries += 1
        
    print_footer(the_number, tries)
    
if __name__ == "__main__":
    main()