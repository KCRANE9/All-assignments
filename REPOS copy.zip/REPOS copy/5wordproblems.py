#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 16 00:13:26 2017

@author: kathy.crane
"""

#% Chapter 2
#% Tyler J. Brough
#% September 8, 2017
# Word Problems
## Word Problems
# Demonstrates numbers and math
#In Chapter 2 of [Python Programming for the Absolute Beginner](), we are presented with some simple `Python` programs to carry out so-called word problems. I reproduce some of Dawson's examples below in the following code chunks. 
#Notice that the output is embedding in the document after the code chunks. 


#{python, evaluate = True}
print("If a wrestler is 300 pounds,")
print("but needs to lose 100 pounds how much will he weigh?")
input("Press the enter key to find out.")
#print("Press the enter key to find out.")
print("300 - 100 =", 300 - 100)


#{python, evaluate = True}
print("\nIf a mother has five babies and buys them")
print("each 2 bottles of apple sauce, how many bottles does she purchase?")
input("Press the enter key to find out.")
#print("Press the enter key to find out.")
print("5 * 2 =", 5 * 2)


#{#python, evaluate = True}
print("\nIf a father has one hundred dollars to give his kids for allowance")
print("and his seven kids split it seven ways, how many whole dollars does each get?")
input("Press the enter key to find out.")
#print("Press the enter key to find out.")
print("100 // 7 =", 100 // 7)


#{python, evaluate = True}
print("\nIf the bill for lunch was 19.50 for four friends")
print("and the four friends split it four ways, how much does each pay?")
input("Press the enter key to find out.")
#print("Press the enter key to find out.")
print("19.50 / 4 =", 19.50 / 4)


#{python, evaluate = True}
print("\nIf a little rascal had one pickle, and then got another pickle,")
print("and then he got another pickle, how much pickles does he have, hey hey hey?")
input("Press the enter key to find out.")
#print("Press the enter key to find out.")
print("1 + 1 + 1 =", 1 + 1 + 1)



#This helps you see how some very simple `Python` syntax works with some string literal values and some basic mathematical operators. Note that I comment out the `input` statements and replace them with `print` statements for the purposes of this document. But try using `input` on your own systems interactively in the REPL. 
## A Simple Assignment
#Your first programming assignment is to come up with five additional simple word problems. Your deliverable will be a Jupyter Notebook in your GitHub account.   
#Try to use different mathemtical operations like multiplication, division, subtraction, and addition. Don't make it too complex though.  
#We can talk some more about it in class.
