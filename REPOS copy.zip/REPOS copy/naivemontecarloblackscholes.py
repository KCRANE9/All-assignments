#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 16 12:04:25 2017

@author: kathy.crane
"""
'''
class VanillaOption(object):
        def __init__(self, strike, expiry):
            self.strike = strike
            self.expiry = expiry
        def value(self,spot):
            pass
        
class VanillaCallOption(VanillaOption):
        def value(self, spot):
            max = np.maximum(spot - self.strike, 0.0)
            return max
class VanillaPutOption(VanillaOption):
    def value(self, spot):
        max = np.maximum(self.strike - spot, 0.0)
        return max
'''
import numpy as np


def CallPayoff(spot, strike):
    return np.maximum(spot - strike, 0.0)


def PutPayoff(spot, strike):
    return np.maximum(strike - spot, 0.0)

def NaiveMonteCarloPricer(option, spot, r, v, q, M, T, K):
   # expiry = option.expiry
    #strike = option.strike
    #(spot, rate, vol, div) = data.get_data()
    #replications = engine.replications
    spot_t = np.empty((M,))
    nudt = (r - q - 0.5 * v * v) * T
    sigdt = v * np.sqrt(T)
    z = np.random.normal(size=int(M,))

#for i in range(M):
#    spot_t[i] = S * np.exp(nudt + sigdt * z[i])
    spot_t = S * np.exp(nudt + sigdt * z)
    call_t = CallPayoff(spot_t, K)
    call_mean = call_t.mean()
    callPrc = np.exp(-r * T) * call_mean
    put_t = PutPayoff(spot_t, K)
    putPrc = np.exp(-r * T) * put_t.mean()
    '''
    dt = T/ M
    disc = np.exp(-rate * dt)
    
    z = np.random.normal(size = M)
    spotT = spot * np.exp((rate - div - 0.5 * vol * vol) * dt + vol * np.sqrt(dt) * z)
    payoffT = option.payoff(spotT)

    prc = payoffT.mean() * disc

    return prc
'''
def main():
    spot = 41.0
    K = 40.0
    r = 0.08
    v = 0.30
    T = 1.0
    q = 0.0
    M = 1000000
    
    theCall = CallPayoff(spot, K)
    callPrice = NaiveMonteCarloPricer(theCall, spot, r, v, q, M, T, K)
    print("The Naive Monte Carlo Call Price is:",(callPrice))
    thePut = PutPayoff(spot, K)
    putPrice = NaiveMonteCarloPricer(thePut, spot, r, v, q, M, T, K)
    print("The American Binomial Put Price is:", (putPrice))
main()

