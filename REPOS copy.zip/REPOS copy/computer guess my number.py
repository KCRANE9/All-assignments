#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  2 15:28:05 2017

@author: kathy.crane
"""

def print_header():
    print("Welcome to 'Computer Guess My Number'!")
    print("I'm thinking of a number between 1 and 100.")
    print("GOOD LUCK.")
    
def print_footer(number, tries):
    print("The computer guessed it! The number was", number)
    print("And it only took the computer", tries, "tries!")
    
def main():
    #print the greeting banner
    print_header()
    
    # set the initial values
    lower_bound = 0
    upper_bound = 100 
    guess = ((upper_bound - lower_bound)//2) 
    tries = 0
#done = false
    number = int(input("Enter a number: "))

# the game loop
    while guess != number:
        guess = ((upper_bound - lower_bound)//2) + lower_bound
        print("The computer takes a guess...", guess)
        if guess > number:
            upper_bound = guess
        elif guess < number:
            lower_bound = guess + 1
            
        #guess = ((upper_bound - lower_bound)//2) + lower_bound
        #print("The computer's guess is:", guess)
        tries +=1    
        #compare with assignment 2 since you put guess in the bottom 
        #of that one and here you put it up above
    print_footer(number, tries)
    print("The computer's guess of", guess,"is correct!")  
  

if __name__ == '__main__':
    main()
  
    # bisect bounds and determine guess
    # output guess to user
    # ask user if guess is correct
    # if guess is correct
        # then exit while loop and give some output
    # else
        # ask user if their number is higher or lower than guess
    # if their number is higher
        # reset your lowerbound to guess
    # else their number is lower
        # reset your upperbound to guess
    #guess = ((upper_bound - lower_bound)/2) + lower_bound
    
    #if high:
        #upper_bound = lower_bound
        #guess = ((upper_bound - lower_bound)/2)
            
   # elif low:
    #    lower_bound = upper_bound
     #   guess = ((upper_bound - lower_bound)/2)
            
      #  done = true
            
#footnote = tries + 1
#done = true
#print("Correct answer. You are awesome.", done)

            