#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 14 17:40:34 2017

@author: kathy.crane
"""

_# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
from scipy.stats import binom

class VanillaOption(object):
        def __init__(self, strike, expiry):
            self.strike = strike
            self.expiry = expiry
        def value(self,spot):
            pass
        
class VanillaCallOption(VanillaOption):
        def value(self, spot):
            max = np.maximum(spot - self.strike, 0.0)
            return max
class VanillaPutOption(VanillaOption):
    def value(self, spot):
        max = np.maximum(self.strike - spot, 0.0)
        return max
    
    
def AmericanBinomialPricer(option, S, rate, volatility, dividend, steps, T):
     #expiry = option.expiry
     nodes = steps + 1
     spotT = 0.0
     callT = 0.0
     dt = T/steps
     u = np.exp(((rate - dividend)*dt) + volatility*np.sqrt(dt))
     d = np.exp(((rate - dividend)*dt) - volatility*np.sqrt(dt))
     pu = (np.exp((rate - dividend)*dt)-d)/(u-d)
     pd = 1 - pu
     discount = np.exp(-rate*dt)
     du = pu * discount
     dp = pd * discount
     spot_price = np.zeros(nodes)
     payoff = np.zeros(nodes)
     for i in range(nodes):
        #spotT = S*(u**(steps-ix))*(d**(i))
         #callT+= option.value(spotT)*binom.pmf(steps - i, steps, pu)
         spot_price[i] = S * (u**(steps - i)) * (d**(i))
         payoff[i] = option.value(spot_price[i])
     for i in range ((steps-1),-1, -1):
         for j in range(i+1):
            payoff[j] = du * payoff[j] + dp * payoff[j+1]
            spot_price[j] = spot_price[j] / u
            payoff[j] = np.maximum(payoff[j], option.value(spot_price[j]))
     #price = callT*np.exp(-rate*T)
     return payoff[0]
 
    
     
    #thePut = VanilllaPutPayoff(K,T)
    #putPrice = EuropeanBinomialPricer(thePut, S, r, v, div, N)
def main():
    S = 41
    X = 40
    rate = 0.08
    T = 1.0
    volatility = 0.30
    #u = 1.2
    dividend = 0.0
    steps = 3
    
    theCall = VanillaCallOption(X,T)
    callPrice = AmericanBinomialPricer(theCall, S, rate, volatility, dividend, steps, T)
    print("The American Binomial Call Price is = {0:.4f}".format(callPrice))
    thePut = VanillaPutOption(X,T)
    putPrice = AmericanBinomialPricer(thePut, S, rate, volatility, dividend, steps, T)
    print("The American Binomial Put Price is = {0:.4f}".format(putPrice))
main()